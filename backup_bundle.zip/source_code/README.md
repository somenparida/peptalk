# HNX26EPS06 — 3D Scene Generation from Blueprints (Mode A)

**Project:** 3D Scene Generation from Blueprints and Room Video  
**Chosen Mode:** Mode A — Floor Plan → 3D Model (GLB)  
**Role:** Member 4 — Integration, Scale Calibration, Validation, Naive Baseline, Held-Out Evaluation & Release  

---

## Architecture Overview

```mermaid
flowchart TD
  A[Floor Plan Input] --> B[Input Validation & PDF Rasterization]
  B --> C[AI Segmentation - Member 1]
  C --> D[Geometry Engine - Member 2]
  D --> E[Scale Calibration Engine - Member 4]
  E --> F[Scene Topology & Bounds Validation - Member 4]
  F --> G[3D Model Extrusion - Member 3]
  G --> H[scene.glb Model]
  H --> I[Three.js Viewer / FastAPI Endpoint]
  D --> J[Evaluation Suite vs Baseline - Member 4]
```

---

## Features & Components

- **Common Contract & Validation:** Standardized `scene_schema.json` (JSON Schema Draft-07) and Pydantic v2 data models (`integration/schemas.py`).
- **Resilient Fallback Architecture:** Dynamic adapter loaders (`integration/adapters.py`) with standalone stubs (`integration/stubs.py`) that run the complete pipeline independently when teammate modules are missing.
- **Multi-Method Scale Calibration:**
  - **Method A (Explicit OCR):** Text extraction via EasyOCR / PyTesseract matched with Hough line segments for exact dimension scaling.
  - **Method B (Reference Door):** Standard door width (0.90 m) reference calibration.
  - **Method C (Estimated):** Wall thickness heuristic / default scale fallback with confidence scoring.
- **Scene Geometry Validator:** Detects disconnected walls, orphan doors/windows, invalid polygons, and bounds violations (`integration/validators.py`).
- **Transparent Naive Baseline Engine:** Contour-based direct extrusion baseline (`evaluation/baseline.py`) for fair benchmark comparison.
- **Comprehensive Evaluation & Ablation Suite:** Layout IoU, placement error, dimension error (MAE & MAPE %), completeness recall, and composite benchmark scoring (`evaluation/evaluate.py`, `evaluation/ablation.py`, `evaluation/compare.py`).
- **FastAPI REST Server:** Upload endpoint `/reconstruct`, health status `/health`, and static `/outputs` serving with CORS enabled for Three.js web viewers.

---

## Installation & Setup

```bash
# Clone repository and navigate to root
git clone <repo_url>
cd hacknex-ps06

# Install dependencies
pip install -r requirements.txt
```

---

## Quickstart & Usage

### 1. Run Pipeline CLI

```bash
# Run proposed geometry pipeline
python scripts/run_pipeline.py data/demo/demo_01.png

# Run naive baseline pipeline for comparison
python scripts/run_pipeline.py data/demo/demo_01.png --baseline
```

Output artifacts generated in `outputs/<plan_name>/`:
- `scene.json` — Standardized scene JSON
- `scene.glb` — Extruded 3D GLB model
- `report.json` — Status, timing, scale, and validation counters
- `wall_mask.png`, `door_mask.png`, `window_mask.png` — Debug segmentation masks

### 2. Run Evaluation Suite & Benchmark

```bash
# Run master evaluation (development, held-out, ablation, and charts)
python scripts/evaluate_all.py
```

### 3. Run FastAPI Backend Server

```bash
uvicorn integration.api:app --reload --port 8000
```
- Health Check: `GET http://127.0.0.1:8000/health`
- Upload Endpoint: `POST http://127.0.0.1:8000/reconstruct`

---

## Benchmark & Ablation Results

Held-out dataset (`plan_07` .. `plan_10`) benchmark results:

| Pipeline Stage | Wall IoU | Dim Error (m) | Dim Rel Error (%) | Invalid Geometry | Composite Score |
|---|---:|---:|---:|---:|---:|
| Baseline (Naive Contour Extrusion) | n/a | 2.015 m | 26.96% | 0.00 | 99.87 |
| + Topology Correction | n/a | 1.411 m | 18.87% | 0.50 | 92.59 |
| + Scale Calibration | n/a | 0.671 m | 9.50% | 0.00 | 81.03 |
| Full (Topology + Scale + Validation) | n/a | 0.610 m | 8.64% | 0.00 | 85.30 |

---

## Running Tests

```bash
PYTHONPATH=. pytest -v tests/
```

---

## Team & Roles

- **Member 1 (AI Segmentation):** `analyze_floorplan(path) -> masks`
- **Member 2 (Geometry Engine):** `reconstruct_geometry(masks) -> scene`
- **Member 3 (3D Extrusion & Viewer):** `generate_3d(scene) -> scene.glb`
- **Member 4 (Integration, Scale, Validation, Baseline, Evaluation, Release):** Integration pipeline, contract enforcement, scale calibration, validators, baseline engine, evaluation suite, FastAPI, CLI, documentation.
